import express from 'express';
import cors from 'cors';
import path from 'path';
import { fileURLToPath } from 'url';

const app = express();
const __dirname = path.dirname(fileURLToPath(import.meta.url));

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, '../frontend')));

const menu = [
  {id:1, category:'japanese', name:'Филадельфия', description:'Лосось, сливочный сыр, рис, нори', price:65000, emoji:'🍣'},
  {id:2, category:'japanese', name:'Калифорния', description:'Краб, авокадо, огурец, икра', price:55000, emoji:'🍣'},
  {id:3, category:'japanese', name:'Рамен', description:'Бульон, лапша, яйцо, курица', price:59000, emoji:'🍜'},
  {id:4, category:'japanese', name:'Гёдза', description:'Японские пельмени с курицей', price:45000, emoji:'🥟'},
  {id:5, category:'european', name:'Бургер Asad', description:'Говядина, сыр, салат, фирменный соус', price:72000, emoji:'🍔'},
  {id:6, category:'european', name:'Паста Alfredo', description:'Паста, курица, сливочный соус, пармезан', price:68000, emoji:'🍝'},
  {id:7, category:'european', name:'Цезарь', description:'Курица, салат, пармезан, соус цезарь', price:52000, emoji:'🥗'},
  {id:8, category:'european', name:'Картофель фри', description:'Хрустящий картофель с соусом', price:25000, emoji:'🍟'}
];

app.get('/api/menu', (req,res) => res.json(menu));

app.post('/api/orders', (req,res) => {
  const order = {
    id: Math.floor(1000 + Math.random()*9000),
    ...req.body,
    status: 'pending_payment',
    createdAt: new Date().toISOString()
  };
  console.log('NEW ORDER', order);
  res.json({ok:true, order});
});

// Заглушка: здесь подключим Telegram invoice/payment provider.
app.post('/api/payment/create', (req,res) => {
  res.status(501).json({
    ok:false,
    message:'Payment provider is not configured yet.'
  });
});

app.get('*', (req,res) => {
  res.sendFile(path.join(__dirname, '../frontend/index.html'));
});

app.listen(3000, () => console.log('AsadFood running on http://localhost:3000'));
